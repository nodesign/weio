from pyuper.uperio import UperIO
u = UperIO()
u.reset()