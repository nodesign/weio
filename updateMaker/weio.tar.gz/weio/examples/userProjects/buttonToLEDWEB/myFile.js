function onWeioReady() {
    digitalWrite(22, LOW);
}






