# No dependencies needed just run pure Python here
print "Hello World!"