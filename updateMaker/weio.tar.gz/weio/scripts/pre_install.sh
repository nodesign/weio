#!/bin/sh
echo "This is WeIO pre install procedure"