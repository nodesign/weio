#!/bin/sh

echo -e "$1\n$1" | passwd
