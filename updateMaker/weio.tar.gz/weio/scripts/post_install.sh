#!/bin/sh
echo "This is WeIO post install procedure"

#cd /
#cp /weio/scripts/weio_run.sh .
#pkill -f "./weio_run.sh"
#pkill -f "python server.py"
#./weio_run.sh&
