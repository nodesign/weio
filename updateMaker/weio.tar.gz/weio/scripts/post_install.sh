#!/bin/sh
echo "This is WeIO post install procedure"

cd /
cp /weio/scripts/run_weio.sh .
pkill -f "./run_weio.sh"
pkill -f "python server.py"
./run_weio.sh&